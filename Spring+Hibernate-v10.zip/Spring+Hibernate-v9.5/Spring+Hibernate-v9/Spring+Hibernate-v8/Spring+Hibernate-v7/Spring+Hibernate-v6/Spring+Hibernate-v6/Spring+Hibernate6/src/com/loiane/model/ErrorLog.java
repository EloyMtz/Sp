package com.loiane.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect
@Entity
@Table(name="errorlog")
public class ErrorLog {
	
	@Id
	@GeneratedValue
	@Column(name="logid")	
	private int logid;
	private String username;
	
	@ManyToOne
	@JoinColumn(name= "errorid")
	private ErrorList fk_error_code;
	
	@ManyToOne
	@JoinColumn(name= "appid")
	private AppList fk_app_code;
	
	
	public int getLogid() {
		return logid;
	}
	public void setLogid(int logid) {
		this.logid = logid;
	}
	
	@Column(name="username", nullable=false)
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	//@Column(name="fk_error_code", nullable=false)
	public ErrorList getFk_error_code() {
		return fk_error_code;
	}
	public void setFk_error_code(ErrorList fk_error_code) {
		this.fk_error_code = fk_error_code;
	}
	
	//@Column(name="fk_app_code", nullable=false)
	public AppList getFk_app_code() {
		return fk_app_code;
	}
	public void setFk_app_code(AppList fk_app_code) {
		this.fk_app_code = fk_app_code;
	}
	
}
