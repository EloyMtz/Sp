angular.module('starter', ['starter.controllers'])

function EditApp(id){

	var url = "http://localhost:8080/extjs-crud-grid-spring-hibernate/";

	$.ajax({
		url: url+'applist/querybyid.action',
		type:'POST',
		data: {"appid":id},
		success: function(data){
			
			var id = data.data.appid;
			var name = data.data.description;
			var status = data.data.status;
			
			$("#appid").val(id);
			$("#appname").val(name);
			$("#appstatus").val(status);
			$("#myModal").modal("show");
		},
		error: function(){
			alert('Error');
		}				
	});
	
}

function DeleteApp(id){
	
	var url = "http://localhost:8080/extjs-crud-grid-spring-hibernate/";

	$.ajax({
		url: url+'applist/delete.action',
		type:'POST',
		data: {"appid":id},
		success: function(){
			alert('App deleted properly');
		},
		error: function(){
			alert('Error deleting App');
		}				
	});
}