package com.loiane.dao;

import java.util.List;

import com.loiane.model.AppList;

public interface IAppListDAO {

	public List<AppList> getAppList();
	public void deleteApp(int appid);
	public AppList saveApp(AppList applist);
}
