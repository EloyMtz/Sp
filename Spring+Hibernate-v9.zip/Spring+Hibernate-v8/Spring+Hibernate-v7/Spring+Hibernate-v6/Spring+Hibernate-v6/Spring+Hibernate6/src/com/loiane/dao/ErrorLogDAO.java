package com.loiane.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.loiane.model.ErrorLog;

@Repository
public class ErrorLogDAO implements IErrorLogDAO {

	private HibernateTemplate hibernateTemplate;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		hibernateTemplate = new HibernateTemplate(sessionFactory);
	}
	
	/**
	 * Get List of contacts from database
	 * @return list of all contacts
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ErrorLog> getErrorsLog() {
		return hibernateTemplate.find("from ErrorLog");
	}

	/**
	 * Delete a contact with the id passed as parameter
	 * @param id
	 */
	@Override
	public void deleteErrorLog(int logid){
		Object record = hibernateTemplate.load(ErrorLog.class, logid);
		hibernateTemplate.delete(record);
	}
	
	/**
	 * Create a new Contact on the database or
	 * Update contact
	 * @param contact
	 * @return contact added or updated in DB
	 */
	@Override
	public ErrorLog saveErrorLog(ErrorLog errorlog){
		hibernateTemplate.saveOrUpdate(errorlog);
		return errorlog;
	}
}
