package com.loiane.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect
@Entity
@Table(name="errorlist")
public class ErrorList {
	@Id
	@GeneratedValue
	@Column(name="errorid")
	private int errorid;
	private String description;
	private String type_error;
	
	
	public int getErrorid() {
		return errorid;
	}
	public void setErrorid(int errorid) {
		this.errorid = errorid;
	}
	
	@Column(name="description", nullable=false)
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Column(name="type_error", nullable=false)
	public String getType_error() {
		return type_error;
	}
	public void setType_error(String type_error) {
		this.type_error = type_error;
	}
}
