package com.loiane.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.loiane.model.AppList;

@Repository
public class AppListDAO implements IAppListDAO{

	private HibernateTemplate hibernateTemplate;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		hibernateTemplate = new HibernateTemplate(sessionFactory);
	}
	
	/**
	 * Get List of contacts from database
	 * @return list of all contacts
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<AppList> getAppList() {
		return hibernateTemplate.find("from AppList");
	}

	/**
	 * Delete a contact with the id passed as parameter
	 * @param id
	 */
	@Override
	public void deleteApp(int appid){
		Object record = hibernateTemplate.load(AppList.class, appid);
		hibernateTemplate.delete(record);
	}
	
	
	public AppList byID(int appid){
		return hibernateTemplate.get(AppList.class, appid);
		//hibernateTemplate.delete(record);
	}
	/**
	 * Create a new Contact on the database or
	 * Update contact
	 * @param contact
	 * @return contact added or updated in DB
	 */
	@Override
	public AppList saveApp(AppList applist){
		hibernateTemplate.saveOrUpdate(applist);
		return applist;
	}
}
