angular.module('starter.controllers', [])


.controller('AppsCtrl', ['$scope','$http',function($scope, $http) {
	
	var url = "http://localhost:8080/extjs-crud-grid-spring-hibernate/";
	
	$.ajax({
	      url: url+"applist/view.action",
	      type: "GET",
	      crossDomain: true,
	      async: true,
	      success: function(data) {
	    	  
	        var large = data.data.length;
	        var tablestatus;
	      
	        for(i=0;i<large;i++){
	        	
	        	var id = data.data[i].appid;
	        	var status = data.data[i].status;
	        	if(status == "1"){
	        		tablestatus = "Active";
	        	}else{
	        		tablestatus = "Inactive";
	        	}
	        	$("#appbody").append("<tr><td>"+data.data[i].appid+"</td><td>"+data.data[i].description+"</td><td>"+tablestatus+"</td><td><a href='#' onclick='EditApp("+id+")'><img src='img/edit.png' height='35px' width='35px'/></a></td><td><a href='#' onclick='DeleteApp("+id+")'><img src='img/delete.png' height='35px' width='35px'/></a></td></tr>");
	        }
	      },
	      error:function(){
	          alert("Error retrieving app list");
	      }
	  }); 
	
	$scope.RefreshAppTable = function(){
			
		$.ajax({
		      url: url+"applist/view.action",
		      type: "GET",
		      crossDomain: true,
		      async: true,
		      success: function(data) {
		    	  
		    	$("#appbody").remove();
		  		$("#apptable").append("<tbody id='appbody'></tbody>");
		    	  
		        var large = data.data.length;
		        var tablestatus;
		      
		        for(i=0;i<large;i++){
		        	
		        	var id = data.data[i].appid;
		        	var status = data.data[i].status;
		        	if(status == "1"){
		        		tablestatus = "Active";
		        	}else{
		        		tablestatus = "Inactive";
		        	}
		        	$("#appbody").append("<tr><td>"+data.data[i].appid+"</td><td>"+data.data[i].description+"</td><td>"+tablestatus+"</td><td><a href='#' onclick='EditApp("+id+")'><img src='img/edit.png' height='35px' width='35px'/></a></td><td><a href='#' onclick='DeleteApp("+id+")'><img src='img/delete.png' height='35px' width='35px'/></a></td></tr>");
		        }
		      },
		      error:function(){
		          alert("Error retrieving app list");
		      }
		  });
	}
	
	$scope.SaveApp = function(){
		
		var appd = $("#appdes").val();
		var status = 1;
		
		if(appd != ""){
			
			$http({
				  method: "POST",
				  url: url+"applist/create.action",
				  data:{description:appd,status:status},
			      contentType: "application/json",
			      crossDomain: true,
			      async: true
				}).then(function successCallback(response) {
					alert("App created succesfully");
				  }, function errorCallback(response) {
					  alert("Error saving the app");
				  });
			
		}else{
			
			alert("Fields stll empty");
		}		
	}
	
	$scope.SaveEditApp = function(){
		
		var id = $("#appid").val();
		var name = $("#appname").val();
		var status = $("#appstatus").val();
		
		if(name != "" && status != ""){
			
			$http({
				  method: "POST",
				  url: url+"applist/create.action",
				  data:{appid:id,description:name,status:status},
			      contentType: "application/json",
			      crossDomain: true,
			      async: true
				}).then(function successCallback(response) {
					alert("App updated succesfully");
				  }, function errorCallback(response) {
					  alert("Error updating the app");
				  });

		}else{
			
			alert("Fields still empty");
		}	
	}
	
	// Error List//
	
	$.ajax({
	      url: url+"errorlist/view.action",
	      type: "GET",
	      crossDomain: true,
	      async: true,
	      success: function(data) {
	    	  
	        var large = data.data.length;
	      
	        for(i=0;i<large;i++){
	        	
	        	var id = data.data[i].appid;
	        	$("#errorLbody").append("<tr><td>"+data.data[i].type_error+"</td><td>"+data.data[i].description+"</td></tr>");
	        }
	      },
	      error:function(){
	          alert("Error retrieving error list");
	      }
	  });
	
	// Error Log//
	
	$.ajax({
	      url: url+"errorlog/view.action",
	      type: "GET",
	      crossDomain: true,
	      async: true,
	      success: function(data) {
	    	  
	        var large = data.data.length;
	      
	        for(i=0;i<large;i++){
	        	
	        	var id = data.data[i].appid;
	        	$("#errorLogbody").append("<tr><td>"+data.data[i].logid+"</td><td>"+data.data[i].username+"</td><td>"+data.data[i].fk_app_code.description+"</td><td>"+data.data[i].fk_error_code.type_error+"</td><td>"+data.data[i].fk_error_code.description+"</td></tr>");
	        }
	      },
	      error:function(){
	          alert("Error retrieving error log");
	      }
	  }); 

}]);

