package com.loiane.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.loiane.model.ErrorL;
import com.loiane.service.ErrorLService;

@Controller
public class ErrorLController  {

	private ErrorLService errorLService;
	
	@RequestMapping(value="/errorList/view.action")
	public @ResponseBody Map<String,? extends Object> view() throws Exception {

		try{

			List<ErrorL> errors = errorLService.getErrorList();

			return getMap(errors);

		} catch (Exception e) {

			return getModelMapError("Error retrieving Error List from database.");
		}
	}
	
	@RequestMapping(value="/errorList/create.action")
	public @ResponseBody Map<String,? extends Object> create(@RequestParam Object data) throws Exception {

		try{

			List<ErrorL> errors = errorLService.create(data);

			return getMap(errors);

		} catch (Exception e) {

			return getModelMapError("Error trying to create errorList.");
		}
	}
	
	@RequestMapping(value="/errorList/update.action")
	public @ResponseBody Map<String,? extends Object> update(@RequestParam Object data) throws Exception {
		try{

			List<ErrorL> errors = errorLService.update(data);

			return getMap(errors);

		} catch (Exception e) {

			return getModelMapError("Error trying to update errorList.");
		}
	}
	
	@RequestMapping(value="/errorList/delete.action")
	public @ResponseBody Map<String,? extends Object> delete(@RequestParam Integer errorid) throws Exception {
		
		try{

			errorLService.delete(errorid);

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			modelMap.put("success", true);

			return modelMap;

		} catch (Exception e) {

			return getModelMapError("Error trying to delete app.");
		}
	}
	
	/**
	 * Generates modelMap to return in the modelAndView
	 * @param apps
	 * @return
	 */
	private Map<String,Object> getMap(List<ErrorL> errors){
		
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		modelMap.put("total", errors.size());
		modelMap.put("data", errors);
		modelMap.put("success", true);
		
		return modelMap;
	}
	
	/**
	 * Generates modelMap to return in the modelAndView in case
	 * of exception
	 * @param msg message
	 * @return
	 */
	private Map<String,Object> getModelMapError(String msg){

		Map<String,Object> modelMap = new HashMap<String,Object>(2);
		modelMap.put("message", msg);
		modelMap.put("success", false);

		return modelMap;
	} 


	@Autowired
	public void setErrorListService(ErrorLService errorLService) {
		this.errorLService = errorLService;
	}

}
