package com.loiane.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.loiane.dao.ErrorLDAO;
import com.loiane.model.ErrorL;
import com.loiane.util.Util;

@Service
public class ErrorLService {
	
	private ErrorLDAO errorLDAO;
	private Util util;

	/**
	 * Get all errorList
	 * @return
	 */
	@Transactional(readOnly=true)
	public List<ErrorL> getErrorList(){

		return errorLDAO.getErrors();
	}
	
	/**
	 * Create new ErrorL/errors
	 * @param data - json data from request
	 * @return created apps
	 */
	@Transactional
	public List<ErrorL> create(Object data){
		
        List<ErrorL> newErrors = new ArrayList<ErrorL>();
		
		List<ErrorL> list = util.getErrorsFromRequest(data);
		
		for (ErrorL errorL : list){
			newErrors.add(errorLDAO.saveErrorL(errorL));
		}
		
		return newErrors;
	}
	
	
	/**
	 * Update errorL/errorL
	 * @param data - json data from request
	 * @return updated errors
	 */
	@Transactional
	public List<ErrorL> update(Object data){
		
		List<ErrorL> returnErrors = new ArrayList<ErrorL>();
		
		List<ErrorL> updatedErrors = util.getErrorsFromRequest(data);
		
		for (ErrorL errorL : updatedErrors){
			returnErrors.add(errorLDAO.saveErrorL(errorL));
		}
		
		return returnErrors;
	}
	
	/**
	 * Delete errorL/errors
	 * @param data - json data from request
	 */
	@Transactional
	public void delete(Object data){
		
		//it is an array - have to cast to array object
		if (data.toString().indexOf('[') > -1){
			
			List<Integer> deleteErrors = util.getListErrorIdFromJSON(data);
			
			for (Integer errorid : deleteErrors){
				errorLDAO.deleteErrorL(errorid);
			}
			
		} else { //it is only one object - cast to object/bean
			
			Integer errorid = Integer.parseInt(data.toString());
			
			errorLDAO.deleteErrorL(errorid);
		}
	}
	

	/**
	 * Spring use - DI
	 * @param appDAO
	 */
	@Autowired
	public void setErrorLDAO(ErrorLDAO errorLDAO) {
		this.errorLDAO = errorLDAO;
	}

	/**
	 * Spring use - DI
	 * @param util
	 */
	@Autowired
	public void setUtil(Util util) {
		this.util = util;
	}
	
}