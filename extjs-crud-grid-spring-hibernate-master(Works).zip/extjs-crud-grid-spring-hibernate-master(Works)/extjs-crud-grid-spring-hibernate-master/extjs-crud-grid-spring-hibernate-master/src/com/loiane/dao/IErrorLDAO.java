package com.loiane.dao;

import java.util.List;

import com.loiane.model.ErrorL;

public interface IErrorLDAO {
	
List<ErrorL> getErrors();
	
	void deleteErrorL(int errorid);
	
	ErrorL saveErrorL(ErrorL errorL);

}