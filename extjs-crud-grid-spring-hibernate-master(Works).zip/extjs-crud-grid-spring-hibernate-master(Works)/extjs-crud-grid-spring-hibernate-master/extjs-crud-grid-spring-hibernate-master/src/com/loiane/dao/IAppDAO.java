package com.loiane.dao;

import java.util.List;

import com.loiane.model.App;

public interface IAppDAO {
	
List<App> getApps();
	
	void deleteApp(int appid);
	
	App saveApp(App app);

}