package com.loiane.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.loiane.model.ErrorL;

@Repository
public class ErrorLDAO implements IErrorLDAO{
	
	private HibernateTemplate hibernateTemplate;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		hibernateTemplate = new HibernateTemplate(sessionFactory);
	}
	
	/**
	 * Get List of errorlist from database
	 * @return list of all errorlist
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ErrorL> getErrors() {
		return hibernateTemplate.find("from ErrorL");
	}

	/**
	 * Delete a app with the id passed as parameter
	 * @param id
	 */
	@Override
	public void deleteErrorL(int errorid){
		Object record = hibernateTemplate.load(ErrorL.class, errorid);
		hibernateTemplate.delete(record);
	}
	
	/**
	 * Create a new ErrorL on the database or
	 * Update ErrorL
	 * @param errorL
	 * @return errorL added or updated in DB
	 */
	@Override
	public ErrorL saveErrorL(ErrorL errorL){
		hibernateTemplate.saveOrUpdate(errorL);
		return errorL;
	}

}
