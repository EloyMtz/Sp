package com.loiane.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.loiane.model.App;

@Repository
public class AppDAO implements IAppDAO{
	
	private HibernateTemplate hibernateTemplate;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		hibernateTemplate = new HibernateTemplate(sessionFactory);
	}
	
	/**
	 * Get List of apps from database
	 * @return list of all apps
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<App> getApps() {
		return hibernateTemplate.find("from App");
	}

	/**
	 * Delete a app with the id passed as parameter
	 * @param id
	 */
	@Override
	public void deleteApp(int appid){
		Object record = hibernateTemplate.load(App.class, appid);
		hibernateTemplate.delete(record);
	}
	
	/**
	 * Create a new App on the database or
	 * Update App
	 * @param app
	 * @return app added or updated in DB
	 */
	@Override
	public App saveApp(App app){
		hibernateTemplate.saveOrUpdate(app);
		return app;
	}

}
