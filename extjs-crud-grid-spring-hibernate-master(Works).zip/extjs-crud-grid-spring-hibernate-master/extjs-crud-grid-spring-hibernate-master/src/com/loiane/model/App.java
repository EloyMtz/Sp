package com.loiane.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonAutoDetect;


@JsonAutoDetect
@Entity
@Table(name="applist")
public class App {
	
	private int id;
	private String description;
	private int status;
	
	@Id
	@GeneratedValue
	@Column(name="appid")
	public int getAppId() {
		return id;
	}
	
	public void setAppId(int id) {
		this.id = id;
	}
	
	@Column(name="description", nullable=false)
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Column(name="status", nullable=false)
	public int getStatus() {
		return status;
	}
	
	public void setStatus(int status) {
		this.status = status;
	}
	
}