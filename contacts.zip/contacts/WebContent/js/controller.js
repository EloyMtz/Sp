angular.module('starter.controllers',[])

.controller('CtCtrl', ['$scope','$http',function($scope, $http) {

	var url = "http://localhost:8080/contacts/";
	var count = 0;
	var offset = 0;
	var rowPP = 5;
	
	
	function getPage(){
		return 5;
	};
	
	$scope.Mostrar = function(){
		
		
		$.ajax({
		      url: url+"contact/view.action",
		      type: "GET",
		      crossDomain: true,
		      async: true,
		      data: {OFFSET:0, LIMIT:100},
		      success: function(data) {
		    	
		    	  $("#myTable").DataTable().destroy();
		    	  $("#contactbody").remove();
		    	  $("#myTable").append("<tbody id='contactbody'></tbody>");
		    	  		    	  
			        var large = data.data.length;		      
			        for(i=0;i<large;i++){		   
			        	
			        	$("#contactbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].email+"</td><td>"+data.data[i].phone+"</td></tr>");
			        }
			        
			        $("#myTable").DataTable({
			        
			            "paging":true,
			            "searching":false
			        });
			      },
			      error:function(){
			          alert("Error retrieving app list");
			      }
			  })
	};
	
//	$scope.righty = function(){
//		if (count == getPage())
//			count = 1;
//		offset = count * rowPP;
//		$.ajax({
//			url: url+"contact/view.action",
//		      type: "GET",
//		      crossDomain: true,
//		      async: true,
//		      data: {OFFSET:0, LIMIT:4},
//		      success: function(data) {
//		    	  
//		        var large = data.data.length;		      
//		        for(i=0;i<large;i++){		   
//		        	
//		        	$("#contactbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].email+"</td><td>"+data.data[i].phone+"</td></tr>");
//		        }
//		      },
//		      error:function(){
//		          alert("Error retrieving app list");
//		      }
//		})
//		count++;
//	};
}]);