package com.loiane.dao;

import java.util.List;

import com.loiane.model.ErrorLog;

public interface IErrorLogDAO {

	public List<ErrorLog> getErrorsLog();
	public void deleteErrorLog(int logid);
	public ErrorLog saveErrorLog(ErrorLog errorlog);
}
