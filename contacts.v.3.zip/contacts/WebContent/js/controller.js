angular.module('starter.controllers',[])

.controller('CtCtrl', ['$scope','$http',function($scope, $http) {

	var url = "http://localhost:8080/contacts/";
	var count = -1;
	var offset = 0;
	var rowPP = $scope.limito;
	
	$.ajax({
	      url: url+"contact/home.action",
	      type: "GET",
	      crossDomain: true,
	      async: true,
	      success: function(data) {
	    	  		    	  
		        var large = data.data.length;		      
		        for(i=0;i<large;i++){		   
		        	
		        	$("#contactbody").append("<tr><td>"+data.data[i].name+"</td>" +
		        			"<td>"+data.data[i].email+"</td><td>"+data.data[i].phone+"</td></tr>");
		        }
		        
		      },
		      error:function(){
		          alert("Error retrieving app list");
		      }
		  });
	
	
	function getPage(){
		return 4;
	};
	
	$scope.changes = function(){		
		count++;
		if (count == getPage())
			count = 0;
		offset = count * $scope.limito;
		$.ajax({
			url: url+"contact/view.action",
		      type: "GET",
		      crossDomain: true,
		      async: true,
		      data: {OFFSET:offset, LIMIT:$scope.limito},
		      success: function(data) {
		    	  
		    	  $("#myTable").DataTable().destroy();
		    	  $("#contactbody").remove();
		    	  $("#myTable").append("<tbody id='contactbody'></tbody>");
		    	  
		        var large = data.data.length;		      
		        for(i=0;i<large;i++){		   
		        	
		        	$("#contactbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].email+"</td><td>"+data.data[i].phone+"</td></tr>");
		        }
		      },
		      error:function(){
		          alert("Error retrieving app list");
		      }
		})
		$scope.index=(count+1);
	};
	
	$scope.righty = function(){
		count++;
		if (count == getPage())
			count = 0;
		offset = count * $scope.limito;
		$.ajax({
			url: url+"contact/view.action",
		      type: "GET",
		      crossDomain: true,
		      async: true,
		      data: {OFFSET:offset, LIMIT:$scope.limito},
		      success: function(data) {
		    	  
		    	  $("#myTable").DataTable().destroy();
		    	  $("#contactbody").remove();
		    	  $("#myTable").append("<tbody id='contactbody'></tbody>");
		    	  
		        var large = data.data.length;		      
		        for(i=0;i<large;i++){		   
		        	
		        	$("#contactbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].email+"</td><td>"+data.data[i].phone+"</td></tr>");
		        }
		      },
		      error:function(){
		          alert("Error retrieving app list");
		      }
		})
		$scope.index=(count+1);
	};
	
	$scope.lefty = function(){
		count--;
		if (count <= -1)
			count = (getPage()-1);
		offset = count * $scope.limito;
		$.ajax({
			url: url+"contact/view.action",
		      type: "GET",
		      crossDomain: true,
		      async: true,
		      data: {OFFSET:offset, LIMIT:$scope.limito},
		      success: function(data) {
		    	  
		    	  $("#myTable").DataTable().destroy();
		    	  $("#contactbody").remove();
		    	  $("#myTable").append("<tbody id='contactbody'></tbody>");
		    	  
		        var large = data.data.length;		      
		        for(i=0;i<large;i++){		   
		        	
		        	$("#contactbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].email+"</td><td>"+data.data[i].phone+"</td></tr>");
		        }
		      },
		      error:function(){
		          alert("Error retrieving app list");
		      }
		})
		$scope.index=(count+1);
	};
}]);