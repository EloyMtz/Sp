package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import model.Contact;

@Repository
public class ContactDAO implements IContactDAO {

	private HibernateTemplate hibernateTemplate;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		hibernateTemplate = new HibernateTemplate(sessionFactory);
	}
	
	/**
	 * Get List of contacts from database
	 * @return list of all contacts
	 */
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Contact> homeContacts() {
		return hibernateTemplate.find("from Contact");
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Contact> getContacts(int OFFSET, int LIMIT) {
//		return hibernateTemplate.find("from Contact");
		String SQL = "call pagination("+OFFSET+", "+LIMIT+")";
		Query QP = hibernateTemplate.getSessionFactory().openSession().createSQLQuery(SQL).addEntity(Contact.class);
		return (List<Contact>)QP.list();
	}

	/**
	 * Delete a contact with the id passed as parameter
	 * @param id
	 */
	@Override
	public void deleteContact(int id){
		Object record = hibernateTemplate.load(Contact.class, id);
		hibernateTemplate.delete(record);
	}
	
	public Contact byID(int id){
		return hibernateTemplate.get(Contact.class, id);
		//hibernateTemplate.delete(record);
	}
	
	@Override
	public Contact saveContact(Contact contact){
		hibernateTemplate.saveOrUpdate(contact);
		return contact;
	}
	
}
