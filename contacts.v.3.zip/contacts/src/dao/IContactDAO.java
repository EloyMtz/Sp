package dao;

import java.util.List;
import model.Contact;

public interface IContactDAO {
	
	public List<Contact> getContacts(int OFFSET, int LIMIT);
	public void deleteContact(int id);
	public Contact saveContact(Contact contact);
	public List<Contact> homeContacts();

}
