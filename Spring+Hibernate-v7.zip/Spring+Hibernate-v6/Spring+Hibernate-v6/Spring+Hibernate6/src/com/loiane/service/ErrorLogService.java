package com.loiane.service;

//import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.loiane.dao.ErrorLogDAO;
import com.loiane.model.ErrorLog;
import com.loiane.util.Util;

@Service
public class ErrorLogService {

	private ErrorLogDAO errorlogDAO;
	private Util util;

	/**
	 * Get all contacts
	 * @return
	 */
	@Transactional(readOnly=true)
	public List<ErrorLog> getLog(){

		return errorlogDAO.getErrorsLog();
	}
	
	/**
	 * Create new Contact/Contacts
	 * @param data - json data from request
	 * @return created contacts
	 */
	@Transactional
	public List<ErrorLog> create(Object data){
		
        List<ErrorLog> newErrorLog = new ArrayList<ErrorLog>();
		
		List<ErrorLog> list = util.getErrorLogFromRequest(data);
		
		for (ErrorLog errorlog : list){
			newErrorLog.add(errorlogDAO.saveErrorLog(errorlog));
		}
		
		return newErrorLog;
	}
	
	
	/**
	 * Update contact/contacts
	 * @param data - json data from request
	 * @return updated contacts
	 */
	@Transactional
	public List<ErrorLog> update(Object data){
		
		List<ErrorLog> returnErrorLog = new ArrayList<ErrorLog>();
		
		List<ErrorLog> updatedErrorLog = util.getErrorLogFromRequest(data);
		
		for (ErrorLog errorlog : updatedErrorLog){
			returnErrorLog.add(errorlogDAO.saveErrorLog(errorlog));
		}
		
		return returnErrorLog;
	}
	
	/**
	 * Delete contact/contacts
	 * @param data - json data from request
	 */
	@Transactional
	public void delete(Object data){
		
		//it is an array - have to cast to array object
		if (data.toString().indexOf('[') > -1){
			
			List<Integer> deleteErrorLog = util.getErrorLogListIdFromJSON(data);
			
			for (Integer logid : deleteErrorLog){
				errorlogDAO.deleteErrorLog(logid);
			}
			
		} else { //it is only one object - cast to object/bean
			
			Integer logid = Integer.parseInt(data.toString());
			
			errorlogDAO.deleteErrorLog(logid);
		}
	}
	

	/**
	 * Spring use - DI
	 * @param contactDAO
	 */
	@Autowired
	public void setErrorLogDAO(ErrorLogDAO errorLogDAO) {
		this.errorlogDAO = errorLogDAO;
	}

	/**
	 * Spring use - DI
	 * @param util
	 */
	@Autowired
	public void setUtil(Util util) {
		this.util = util;
	}
}
