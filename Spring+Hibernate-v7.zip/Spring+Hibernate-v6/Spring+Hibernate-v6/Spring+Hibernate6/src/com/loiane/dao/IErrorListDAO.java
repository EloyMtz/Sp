package com.loiane.dao;

import java.util.List;

import com.loiane.model.ErrorList;

public interface IErrorListDAO {
	
	public List<ErrorList> getErrorsList();
	public void deleteError(int errorid);
	public ErrorList saveError(ErrorList errorlist);
}
