package com.loiane.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.loiane.model.AppList;
import com.loiane.service.AppListService;

import net.sf.json.JSONObject;;

@Controller
public class AppListController {
	
private AppListService appListService;
	
	@RequestMapping(value="/applist/view.action")
	public @ResponseBody Map<String,? extends Object> view() throws Exception {

		try{

			List<AppList> applist = appListService.getAppList();

			return getMap(applist);

		} catch (Exception e) {

			return getModelMapError("Error retrieving the App list from database.");
		}
	}
	
	@RequestMapping(value="/applist/create.action")
	public @ResponseBody Map<String,? extends Object> create(@RequestBody JSONObject data) throws Exception {
		//System.out.println("Hola");
		System.out.println(data);
		try{

			AppList applist = appListService.create(data);

			return getMapApp(applist);

		} catch (Exception e) {

			return getModelMapError("Error trying to create App.");
		}
	}
	
	@RequestMapping(value="/applist/update.action")
	public @ResponseBody Map<String,? extends Object> update(@RequestParam Object data) throws Exception {
		
		try{

			List<AppList> applist = appListService.update(data);

			return getMap(applist);

		} catch (Exception e) {

			return getModelMapError("Error trying to update App.");
		}
	}
	
	@RequestMapping(value="/applist/delete.action")
	public @ResponseBody Map<String,? extends Object> delete(@RequestParam Integer appid) throws Exception {
		
		try{

			appListService.delete(appid);

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			modelMap.put("success", true);

			return modelMap;

		} catch (Exception e) {

			return getModelMapError("Error trying to delete App.");
		}
	}
	
	@RequestMapping(value="/applist/querybyid.action")
	public @ResponseBody Map<String,? extends Object> ByID(@RequestParam Integer appid) throws Exception {
		
		try{
			
			AppList applist = appListService.byID(appid);

			return getMapApp(applist);
		

		} catch (Exception e) {

			return getModelMapError("Error trying to retrieve the App.");
		}
	}
	
	/**
	 * Generates modelMap to return in the modelAndView
	 * @param contacts
	 * @return
	 */
	private Map<String,Object> getMap(List<AppList> applist){
		
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		modelMap.put("total", applist.size());
		modelMap.put("data", applist);
		modelMap.put("success", true);
		
		return modelMap;
	}
	
private Map<String,Object> getMapApp(Object applist){
		
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		modelMap.put("total", 1);
		modelMap.put("data", applist);
		modelMap.put("success", true);
		
		return modelMap;
	}

	
	/**
	 * Generates modelMap to return in the modelAndView in case
	 * of exception
	 * @param msg message
	 * @return
	 */
	private Map<String,Object> getModelMapError(String msg){

		Map<String,Object> modelMap = new HashMap<String,Object>(2);
		modelMap.put("message", msg);
		modelMap.put("success", false);

		return modelMap;
	} 


	@Autowired
	public void setAppListService(AppListService appListService) {
		this.appListService = appListService;
	}

}
