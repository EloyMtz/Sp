package com.loiane.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect
@Entity
@Table(name="errorlist")
public class ErrorList {

	private int errorid;
	private String description;
	
	@Id
	@GeneratedValue
	@Column(name="errorid")
	public int getErrorid() {
		return errorid;
	}
	public void setErrorid(int errorid) {
		this.errorid = errorid;
	}
	
	@Column(name="description", nullable=false)
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
