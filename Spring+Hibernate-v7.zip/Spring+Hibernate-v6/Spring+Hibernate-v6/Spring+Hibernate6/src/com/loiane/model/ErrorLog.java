package com.loiane.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect
@Entity
@Table(name="errorlog")
public class ErrorLog {
	
	private int logid;
	private String username;
	private int fk_error_code;
	private int fk_app_code;
	
	@Id
	@GeneratedValue
	@Column(name="logid")
	public int getLogid() {
		return logid;
	}
	public void setLogid(int logid) {
		this.logid = logid;
	}
	
	@Column(name="username", nullable=false)
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	@Column(name="fk_error_code", nullable=false)
	public int getFk_error_code() {
		return fk_error_code;
	}
	public void setFk_error_code(int fk_error_code) {
		this.fk_error_code = fk_error_code;
	}
	
	@Column(name="fk_app_code", nullable=false)
	public int getFk_app_code() {
		return fk_app_code;
	}
	public void setFk_app_code(int fk_app_code) {
		this.fk_app_code = fk_app_code;
	}
	
}
