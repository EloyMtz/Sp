package com.loiane.util;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.stereotype.Component;

import com.loiane.model.Contact;
import com.loiane.model.ErrorLog;
import com.loiane.model.ErrorList;
import com.loiane.model.AppList;

/**
 * Util class. Contains some common methods that can be used
 * for any class
 * 
 * @author Loiane Groner
 * http://loianegroner.com (English)
 * http://loiane.com (Portuguese)
 */
@Component
public class Util {
	
	/**
	 * Get list of Contacts from request.
	 * @param data - json data from request 
	 * @return list of Contacts
	 */
	public List<Contact> getContactsFromRequest(Object data){

		List<Contact> list;

		//it is an array - have to cast to array object
		if (data.toString().indexOf('[') > -1){

			list = getListContactsFromJSON(data);

		} else { //it is only one object - cast to object/bean

			Contact contact = getContactFromJSON(data);

			list = new ArrayList<Contact>();
			list.add(contact);
		}

		return list;
	}
	
	@SuppressWarnings("unchecked")
	public List<ErrorLog> getErrorLogFromRequest(Object data){

		List<ErrorLog> list;

		//it is an array - have to cast to array object
		if (data.toString().indexOf('[') > -1){

			list = (List<ErrorLog>) getErrorLogFromJSON(data);

		} else { //it is only one object - cast to object/bean

			ErrorLog errorlog = (ErrorLog) getErrorLogListFromJSON(data);

			list = new ArrayList<ErrorLog>();
			list.add(errorlog);
		}

		return list;
	}
	
	@SuppressWarnings("unchecked")
	public List<ErrorList> getErrorListFromRequest(Object data){

		List<ErrorList> list;

		//it is an array - have to cast to array object
		if (data.toString().indexOf('[') > -1){

			list = (List<ErrorList>) getErrorFromJSON(data);

		} else { //it is only one object - cast to object/bean

			ErrorList errorlist = (ErrorList) getErrorListFromJSON(data);

			list = new ArrayList<ErrorList>();
			list.add(errorlist);
		}

		return list;
	}
	
	@SuppressWarnings("unchecked")
	public List<AppList> getAppListFromRequest(Object data){

		List<AppList> list;

		//it is an array - have to cast to array object
		if (data.toString().indexOf('[') > -1){

			list = (List<AppList>) getAppFromJSON(data);

		} else { //it is only one object - cast to object/bean

			AppList applist = (AppList) getAppListFromJSON(data);

			list = new ArrayList<AppList>();
			list.add(applist);
		}

		return list;
	}

	/**
	 * Transform json data format into Contact object
	 * @param data - json data from request
	 * @return 
	 */
	private Contact getContactFromJSON(Object data){
		JSONObject jsonObject = JSONObject.fromObject(data);
		Contact newContact = (Contact) JSONObject.toBean(jsonObject, Contact.class);
		return newContact;
	}
	
	private ErrorLog getErrorLogFromJSON(Object data){
		JSONObject jsonObject = JSONObject.fromObject(data);
		ErrorLog newErrorLog = (ErrorLog) JSONObject.toBean(jsonObject, ErrorLog.class);
		return newErrorLog;
	}
	
	private ErrorList getErrorFromJSON(Object data){
		JSONObject jsonObject = JSONObject.fromObject(data);
		ErrorList newErrorList = (ErrorList) JSONObject.toBean(jsonObject, ErrorList.class);
		return newErrorList;
	}
	
	private AppList getAppFromJSON(Object data){
		JSONObject jsonObject = JSONObject.fromObject(data);
		AppList newAppList = (AppList) JSONObject.toBean(jsonObject, AppList.class);
		return newAppList;
	}

	/**
	 * Transform json data format into list of Contact objects
	 * @param data - json data from request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<Contact> getListContactsFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<Contact> newContacts = (List<Contact>) JSONArray.toCollection(jsonArray,Contact.class);
		return newContacts;
	}
	
	@SuppressWarnings("unchecked")
	private List<ErrorLog> getErrorLogListFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<ErrorLog> newErrorLog = (List<ErrorLog>) JSONArray.toCollection(jsonArray,ErrorLog.class);
		return newErrorLog;
	}
	
	@SuppressWarnings("unchecked")
	private List<ErrorList> getErrorListFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<ErrorList> newErrorList = (List<ErrorList>) JSONArray.toCollection(jsonArray,ErrorList.class);
		return newErrorList;
	}
	
	@SuppressWarnings("unchecked")
	private List<AppList> getAppListFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<AppList> newAppList = (List<AppList>) JSONArray.toCollection(jsonArray,AppList.class);
		return newAppList;
	}

	/**
	 * Tranform array of numbers in json data format into
	 * list of Integer
	 * @param data - json data from request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Integer> getListIdFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<Integer> idContacts = (List<Integer>) JSONArray.toCollection(jsonArray,Integer.class);
		return idContacts;
	}
	
	@SuppressWarnings("unchecked")
	public List<Integer> getErrorLogListIdFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<Integer> logid = (List<Integer>) JSONArray.toCollection(jsonArray,Integer.class);
		return logid;
	}
	
	@SuppressWarnings("unchecked")
	public List<Integer> getErrorListIdFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<Integer> errorid = (List<Integer>) JSONArray.toCollection(jsonArray,Integer.class);
		return errorid;
	}
	
	@SuppressWarnings("unchecked")
	public List<Integer> getAppListIdFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<Integer> appid = (List<Integer>) JSONArray.toCollection(jsonArray,Integer.class);
		return appid;
	}
}
