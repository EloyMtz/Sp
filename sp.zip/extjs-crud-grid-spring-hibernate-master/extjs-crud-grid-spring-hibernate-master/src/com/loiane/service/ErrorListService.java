package com.loiane.service;

//import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.loiane.dao.ErrorListDAO;
import com.loiane.model.ErrorList;
import com.loiane.util.Util;

@Service
public class ErrorListService {
	
	private ErrorListDAO errorListDAO;
	private Util util;

	/**
	 * Get all applist
	 * @return
	 */
	@Transactional(readOnly=true)
	public List<ErrorList> getErrorListList(){

		return errorListDAO.getErrorList();
	}
	
	/**
	 * Create new Contact/Contacts
	 * @param data - json data from request
	 * @return created contacts
	 */
	@Transactional
	public List<ErrorList> create(Object data){
		
        List<ErrorList> newErrorList = new ArrayList<ErrorList>();
		
		List<ErrorList> list = util.getErrorListFromRequest(data);
		
		for (ErrorList errorList : list){
			newErrorList.add(errorListDAO.saveErrorList(errorList));
		}
		
		return newErrorList;
	}
	
	
	/**
	 * Update contact/contacts
	 * @param data - json data from request
	 * @return updated contacts
	 */
	@Transactional
	public List<ErrorList> update(Object data){
		
		List<ErrorList> returnErrorList = new ArrayList<ErrorList>();
		
		List<ErrorList> updatederrorList = util.getErrorListFromRequest(data);
		
		for (ErrorList errorList : updatederrorList){
			returnErrorList.add(errorListDAO.saveErrorList(errorList));
		}
		
		return returnErrorList;
	}
	
	/**
	 * Delete contact/contacts
	 * @param data - json data from request
	 */
	@Transactional
	public void delete(Object data){
		
		//it is an array - have to cast to array object
		if (data.toString().indexOf('[') > -1){
			
			List<Integer> deleteErrorList = util.getListErrorIdFromJSON(data);
			
			for (Integer errorid : deleteErrorList){
				errorListDAO.deleteErrorList(errorid);
			}
			
		} else { //it is only one object - cast to object/bean
			
			Integer errorid = Integer.parseInt(data.toString());
			
			errorListDAO.deleteErrorList(errorid);
		}
	}
	

	/**
	 * Spring use - DI
	 * @param contactDAO
	 */
	@Autowired
	public void setErrorListDAO(ErrorListDAO errorListDAO) {
		this.errorListDAO = errorListDAO;
	}

	/**
	 * Spring use - DI
	 * @param util
	 */
	@Autowired
	public void setUtil(Util util) {
		this.util = util;
	}
	
}
