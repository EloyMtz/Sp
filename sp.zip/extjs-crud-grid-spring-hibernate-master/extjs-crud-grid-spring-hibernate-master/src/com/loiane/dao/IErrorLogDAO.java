package com.loiane.dao;

import java.util.List;
import com.loiane.model.ErrorLog;

public interface IErrorLogDAO {
	
List<ErrorLog> getErrorLogs();
	
	void deleteErrorLog(int logid);
	
	ErrorLog saveErrorLog(ErrorLog errorLog);

}