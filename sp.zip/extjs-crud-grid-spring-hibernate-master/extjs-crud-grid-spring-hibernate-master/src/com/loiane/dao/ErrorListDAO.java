package com.loiane.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.loiane.model.ErrorList;

@Repository
public class ErrorListDAO implements IErrorListDAO {

	private HibernateTemplate hibernateTemplate;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		hibernateTemplate = new HibernateTemplate(sessionFactory);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ErrorList> getErrorList() {
		return hibernateTemplate.find("from errorlist");
	}

	/**
	 * Delete a contact with the id passed as parameter
	 * 
	 * @param id
	 */
	@Override
	public void deleteErrorList(int errorlist) {
		Object record = hibernateTemplate.load(ErrorList.class, errorlist);
		hibernateTemplate.delete(record);
	}

	/**
	 * Create a new Contact on the database or Update contact
	 * 
	 * @param contact
	 * @return contact added or updated in DB
	 */
	@Override
	public ErrorList saveErrorList(ErrorList errorList) {
		hibernateTemplate.saveOrUpdate(errorList);
		return errorList;
	}

}
