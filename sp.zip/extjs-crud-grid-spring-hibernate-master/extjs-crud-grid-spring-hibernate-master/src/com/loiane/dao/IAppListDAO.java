package com.loiane.dao;

import java.util.List;

import com.loiane.model.AppList;

public interface IAppListDAO {
	
List<AppList> getAppList();
	
	void deleteAppList(int appid);
	
	AppList saveAppList(AppList appList);

}