package com.loiane.dao;

import java.util.List;

import com.loiane.model.ErrorList;

public interface IErrorListDAO {
	
List<ErrorList> getErrorList();
	
	void deleteErrorList(int errorid);
	
	ErrorList saveErrorList(ErrorList errorList);

}