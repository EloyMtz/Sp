package com.loiane.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonAutoDetect;


@JsonAutoDetect
@Entity
@Table(name="errorlist")
public class ErrorList {
	
	private int errorid;
	private String description;
	
	@Id
	@GeneratedValue
	@Column(name="errorid")
	public int getErrorId() {
		return errorid;
	}
	
	public void setErrorId(int errorid) {
		this.errorid = errorid;
	}
	
	@Column(name="description", nullable=false)
	public String getdescription() {
		return description;
	}
	public void setdescription(String description) {
		this.description = description;
	}
}
