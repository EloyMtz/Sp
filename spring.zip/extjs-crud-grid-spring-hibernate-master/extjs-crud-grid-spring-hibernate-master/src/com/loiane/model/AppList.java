package com.loiane.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonAutoDetect;


@JsonAutoDetect
@Entity
@Table(name="applist")
public class AppList {
	
	private int appid;
	private String description;
	private int status;
	
	@Id
	@GeneratedValue
	@Column(name="appid")
	public int getAppId() {
		return appid;
	}
	
	public void setAppId(int appid) {
		this.appid = appid;
	}
	
	@Column(name="description", nullable=false)
	public String getdescription() {
		return description;
	}
	public void setdescription(String description) {
		this.description = description;
	}
	
	@Column(name="status", nullable=false)
	public int getstatus() {
		return status;
	}
	public void setstatus(int status) {
		this.status = status;
	}
		
}
