package com.loiane.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.loiane.model.AppList;


@Repository
public class AppListDAO implements IAppListDAO {

	private HibernateTemplate hibernateTemplate;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		hibernateTemplate = new HibernateTemplate(sessionFactory);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AppList> getAppList() {
		return hibernateTemplate.find("from applist");
	}

	/**
	 * Delete a contact with the id passed as parameter
	 * 
	 * @param id
	 */
	@Override
	public void deleteAppList(int applist) {
		Object record = hibernateTemplate.load(AppList.class, applist);
		hibernateTemplate.delete(record);
	}

	/**
	 * Create a new Contact on the database or Update contact
	 * 
	 * @param contact
	 * @return contact added or updated in DB
	 */
	@Override
	public AppList saveAppList(AppList appList) {
		hibernateTemplate.saveOrUpdate(appList);
		return appList;
	}

}
