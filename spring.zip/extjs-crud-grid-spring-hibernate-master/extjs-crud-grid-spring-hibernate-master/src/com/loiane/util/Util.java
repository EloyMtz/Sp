package com.loiane.util;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.stereotype.Component;

import com.loiane.model.AppList;
import com.loiane.model.Contact;
import com.loiane.model.ErrorLog;
import com.loiane.model.ErrorList;

/**
 * Util class. Contains some common methods that can be used
 * for any class
 * 
 * @author Loiane Groner
 * http://loianegroner.com (English)
 * http://loiane.com (Portuguese)
 */
@Component
public class Util {
	
	/**
	 * Get list of Contacts from request.
	 * @param data - json data from request 
	 * @return list of Contacts
	 */
	public List<Contact> getContactsFromRequest(Object data){

		List<Contact> list;

		//it is an array - have to cast to array object
		if (data.toString().indexOf('[') > -1){

			list = getListContactsFromJSON(data);

		} else { //it is only one object - cast to object/bean

			Contact contact = getContactFromJSON(data);

			list = new ArrayList<Contact>();
			list.add(contact);
		}

		return list;
	}

	/**
	 * Transform json data format into Contact object
	 * @param data - json data from request
	 * @return 
	 */
	private Contact getContactFromJSON(Object data){
		JSONObject jsonObject = JSONObject.fromObject(data);
		Contact newContact = (Contact) JSONObject.toBean(jsonObject, Contact.class);
		return newContact;
	}

	/**
	 * Transform json data format into list of Contact objects
	 * @param data - json data from request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<Contact> getListContactsFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<Contact> newContacts = (List<Contact>) JSONArray.toCollection(jsonArray,Contact.class);
		return newContacts;
	}

	/**
	 * Tranform array of numbers in json data format into
	 * list of Integer
	 * @param data - json data from request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Integer> getListIdFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<Integer> idContacts = (List<Integer>) JSONArray.toCollection(jsonArray,Integer.class);
		return idContacts;
	}
	
	///////////////  ERROR LOG ///////////////////////////////////
	
	public List<ErrorLog> getErrorLogFromRequest(Object data){

		List<ErrorLog> list;

		//it is an array - have to cast to array object
		if (data.toString().indexOf('[') > -1){

			list = getListErrorLogsFromJSON(data);

		} else { //it is only one object - cast to object/bean

			ErrorLog errorLog = getErrorLogFromJSON(data);

			list = new ArrayList<ErrorLog>();
			list.add(errorLog);
		}

		return list;
	}

	/**
	 * Transform json data format into Contact object
	 * @param data - json data from request
	 * @return 
	 */
	private ErrorLog getErrorLogFromJSON(Object data){
		JSONObject jsonObject = JSONObject.fromObject(data);
		ErrorLog newErrorLog = (ErrorLog) JSONObject.toBean(jsonObject, ErrorLog.class);
		return newErrorLog;
	}

	/**
	 * Transform json data format into list of Contact objects
	 * @param data - json data from request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<ErrorLog> getListErrorLogsFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<ErrorLog> newErrorLogs = (List<ErrorLog>) JSONArray.toCollection(jsonArray,ErrorLog.class);
		return newErrorLogs;
	}

	/**
	 * Tranform array of numbers in json data format into
	 * list of Integer
	 * @param data - json data from request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Integer> getListLogIdFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<Integer> idErrorLogs = (List<Integer>) JSONArray.toCollection(jsonArray,Integer.class);
		return idErrorLogs;
	}
	
	
	
	
		///////////////  AppList   ///////////////////////////////////

	public List<AppList> getAppListFromRequest(Object data){

		List<AppList> list;

		//it is an array - have to cast to array object
		if (data.toString().indexOf('[') > -1){

			list = getListAppListFromJSON(data);

		} else { //it is only one object - cast to object/bean

			AppList appList = getAppListFromJSON(data);

			list = new ArrayList<AppList>();
			list.add(appList);
		}

		return list;
	}

	/**
	 * Transform json data format into Contact object
	 * @param data - json data from request
	 * @return 
	 */
	private AppList getAppListFromJSON(Object data){
		JSONObject jsonObject = JSONObject.fromObject(data);
		AppList newAppList = (AppList) JSONObject.toBean(jsonObject, AppList.class);
		return newAppList;
	}

	/**
	 * Transform json data format into list of Contact objects
	 * @param data - json data from request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<AppList> getListAppListFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<AppList> newAppList = (List<AppList>) JSONArray.toCollection(jsonArray,AppList.class);
		return newAppList;
	}

	/**
	 * Tranform array of numbers in json data format into
	 * list of Integer
	 * @param data - json data from request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Integer> getListAppIdFromJSON(Object data){
		JSONArray jsonArray = JSONArray.fromObject(data);
		List<Integer> idAppList = (List<Integer>) JSONArray.toCollection(jsonArray,Integer.class);
		return idAppList;
	}
	

	///////////////  ErrorList   ///////////////////////////////////

public List<ErrorList> getErrorListFromRequest(Object data){

	List<ErrorList> list;

	//it is an array - have to cast to array object
	if (data.toString().indexOf('[') > -1){

		list = getListErrorListFromJSON(data);

	} else { //it is only one object - cast to object/bean

		ErrorList errorList = getErrorListFromJSON(data);

		list = new ArrayList<ErrorList>();
		list.add(errorList);
	}

	return list;
}

/**
 * Transform json data format into Contact object
 * @param data - json data from request
 * @return 
 */
private ErrorList getErrorListFromJSON(Object data){
	JSONObject jsonObject = JSONObject.fromObject(data);
	ErrorList newErrorList = (ErrorList) JSONObject.toBean(jsonObject, ErrorList.class);
	return newErrorList;
}

/**
 * Transform json data format into list of Contact objects
 * @param data - json data from request
 * @return
 */
@SuppressWarnings("unchecked")
private List<ErrorList> getListErrorListFromJSON(Object data){
	JSONArray jsonArray = JSONArray.fromObject(data);
	List<ErrorList> newErrorList = (List<ErrorList>) JSONArray.toCollection(jsonArray,ErrorList.class);
	return newErrorList;
}

/**
 * Tranform array of numbers in json data format into
 * list of Integer
 * @param data - json data from request
 * @return
 */
@SuppressWarnings("unchecked")
public List<Integer> getListErrorIdFromJSON(Object data){
	JSONArray jsonArray = JSONArray.fromObject(data);
	List<Integer> idErrorList = (List<Integer>) JSONArray.toCollection(jsonArray,Integer.class);
	return idErrorList;
}
}
