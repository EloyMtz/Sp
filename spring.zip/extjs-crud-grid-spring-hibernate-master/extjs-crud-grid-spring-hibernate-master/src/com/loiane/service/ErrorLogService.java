package com.loiane.service;

//import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.loiane.dao.ErrorLogDAO;
import com.loiane.model.ErrorLog;
import com.loiane.util.Util;

@Service
public class ErrorLogService {
	
	private ErrorLogDAO errorLogDAO;
	private Util util;

	/**
	 * Get all contacts
	 * @return
	 */
	@Transactional(readOnly=true)
	public List<ErrorLog> getErrorLogList(){

		return errorLogDAO.getErrorLogs();
	}
	
	/**
	 * Create new Contact/Contacts
	 * @param data - json data from request
	 * @return created contacts
	 */
	@Transactional
	public List<ErrorLog> create(Object data){
		
        List<ErrorLog> newContacts = new ArrayList<ErrorLog>();
		
		List<ErrorLog> list = util.getErrorLogFromRequest(data);
		
		for (ErrorLog errorLog : list){
			newContacts.add(errorLogDAO.saveErrorLog(errorLog));
		}
		
		return newContacts;
	}
	
	
	/**
	 * Update contact/contacts
	 * @param data - json data from request
	 * @return updated contacts
	 */
	@Transactional
	public List<ErrorLog> update(Object data){
		
		List<ErrorLog> returnErrorLogs = new ArrayList<ErrorLog>();
		
		List<ErrorLog> updatederrorLogs = util.getErrorLogFromRequest(data);
		
		for (ErrorLog errorLog : updatederrorLogs){
			returnErrorLogs.add(errorLogDAO.saveErrorLog(errorLog));
		}
		
		return returnErrorLogs;
	}
	
	/**
	 * Delete contact/contacts
	 * @param data - json data from request
	 */
	@Transactional
	public void delete(Object data){
		
		//it is an array - have to cast to array object
		if (data.toString().indexOf('[') > -1){
			
			List<Integer> deleteErrorLog = util.getListLogIdFromJSON(data);
			
			for (Integer logid : deleteErrorLog){
				errorLogDAO.deleteErrorLog(logid);
			}
			
		} else { //it is only one object - cast to object/bean
			
			Integer logid = Integer.parseInt(data.toString());
			
			errorLogDAO.deleteErrorLog(logid);
		}
	}
	

	/**
	 * Spring use - DI
	 * @param contactDAO
	 */
	@Autowired
	public void setErrorLogDAO(ErrorLogDAO errorLogDAO) {
		this.errorLogDAO = errorLogDAO;
	}

	/**
	 * Spring use - DI
	 * @param util
	 */
	@Autowired
	public void setUtil(Util util) {
		this.util = util;
	}
	
}
